/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author killer
 */

import java.util.Random;
public class NJ {
    int arra[][]=new int[3][3];
    public void randomm(){
        
        
    }
}
